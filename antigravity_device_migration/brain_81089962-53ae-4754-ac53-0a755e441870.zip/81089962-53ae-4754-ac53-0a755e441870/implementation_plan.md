# Implementation Plan: Independent Dual-Annotator Audit & Inter-Annotator Agreement (IAA) Pipeline

## 1. Goal & Overview

Build and synchronize a self-contained, resumable **Independent Dual-Annotator Audit & Inter-Annotator Agreement (IAA)** script ([run_independent_audit_iaa.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/run_independent_audit_iaa.py)) across both repositories (`1DEV/SKRIPSI` and `SKRIPSI/skripsi`) to evaluate the newly verified 18-class NERGRIT datasets using two independent high-reasoning LLM auditors via local **9router** (`http://localhost:20128/v1`):

1. **Annotator A1**: `cx/gpt-6-luna` with **High Thinking Effort** (`reasoning_effort: "high"`).
2. **Annotator A2**: `ag/gemini-3.8-flash-high` (**Antigravity Gemini 3.8 Flash High Thinking Effort**, `reasoning_effort: "high"`).

> [!IMPORTANT]
> **Why `AUDIT_PROMPT` Must Be Updated to the Stage 2 NERGRIT 18-Class Standard**
> The legacy [run_independent_audit_iaa.py](file:///C:/Users/tream/OneDrive/Documents/SKRIPSI/skripsi/scripts/run_independent_audit_iaa.py) used pre-NERGRIT rules (e.g., classifying `KPK`/`Polri`/`Kementerian`/political parties as `ORG`, stripping attached ranks like `Dr.`/`Jenderal` out of `PER`, and omitting lowercase vehicles/commodities from `PRD` or time durations from `QTY`).
> Our three newly verified datasets (`nemotron`, `luna`, `gemma`) were verified under the strict **18-Class NERGRIT Specification** ([NERGRIT_VERIFICATION_PROMPT.md](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/docs/NERGRIT_VERIFICATION_PROMPT.md)). Updating `AUDIT_PROMPT` to enforce the exact same 18-class NERGRIT taxonomy and boundary rules ensures both auditors (`A1` and `A2`) judge the datasets against the true NERGRIT ground-truth standard.

---

## 2. Pipeline Architecture

```mermaid
flowchart TD
    subgraph Inputs["1. Verified 18-Class Corpora"]
        D1["nemotron: data/distilled_nemotron_verified/corrected.jsonl (17,525 sents)"]
        D2["luna: data/distilled_luna_verified/corrected.jsonl (17,427 sents)"]
        D3["gemma: data/distilled_gemma_verified/corrected.jsonl (17,434 sents)"]
        D0["(Optional) gold / gpt_oss / benchmark"]
    end

    subgraph Sampling["2. Stratified Sampling (Seed 20261022)"]
        S1["100 unique sentences per dataset"]
        S2["6 strata: E0/E1/E2PLUS × SHORT/LONG"]
        S3["Manifest + SHA-256 lock: audit_sample_manifest.json"]
    end

    subgraph Execution["3. Independent Dual-Annotator Execution (Local 9router)"]
        A1["Annotator A1: cx/gpt-6-luna (reasoning_effort='high')"]
        A2["Annotator A2: ag/gemini-3.8-flash-high (reasoning_effort='high')"]
        CK1["Per-sample checkpoints: annotator_A1/samples/*.json"]
        CK2["Per-sample checkpoints: annotator_A2/samples/*.json"]
    end

    subgraph Metrics["4. IAA & Dual-Agreement Consensus"]
        M1["Token Cohen's κ (37 BIO tags & 18 classes + O)"]
        M2["Entity Decision κ (KEEP/REMOVE/REPLACE & Binary)"]
        M3["Pairwise Exact Span-F1 + 1,000x Bootstrap 95% CI"]
        M4["Dataset Precision / Recall / F1 vs Dual-Agreement Consensus"]
        OUT["Outputs: iaa_summary.json, IAA_REPORT.md, CSVs, audit_iaa_results.zip"]
    end

    Inputs --> Sampling
    Sampling --> A1 & A2
    A1 --> CK1 --> Metrics
    A2 --> CK2 --> Metrics
    Metrics --> OUT
```

---

## 3. Proposed Changes

### 3.1. Self-Contained Corpus Loader & Stratified Sampler
- **File**: [scripts/run_independent_audit_iaa.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/run_independent_audit_iaa.py) (created in `1DEV/SKRIPSI` and synced to `SKRIPSI/skripsi`)
- **Remove Broken Legacy Dependency**: The legacy script imported `bab4_pipeline` from `notebooks/` (absent in `1DEV/SKRIPSI`) and read from `bab4_results_raw_v2/prepared/` (no longer present in either repo).
- **Direct Verified Dataset Loading**:
  - Load `nemotron` from [data/distilled_nemotron_verified/corrected.jsonl](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/data/distilled_nemotron_verified/corrected.jsonl) (`17,525` sentences).
  - Load `luna` from [data/distilled_luna_verified/corrected.jsonl](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/data/distilled_luna_verified/corrected.jsonl) (`17,427` sentences).
  - Load `gemma` from [data/distilled_gemma_verified/corrected.jsonl](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/data/distilled_gemma_verified/corrected.jsonl) (`17,434` sentences).
  - Support loading `gold` (`17,431` sentences from [nemotron_18class_colab_bundle.zip](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/nemotron_18class_colab_bundle.zip) or `bab4_source_bundle.zip`) and legacy `gpt_oss` / `benchmark` if selected via `--datasets`.
  - Convert entity lists `{text, entities: [{entity, type}]}` to token-level BIO tags using the exact `align_entities_to_bio` and `entity_spans` functions used in [cell5.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell5.py).
- **Stratified Sampling**:
  - Draw `100` unique sentences per dataset (`seed = 20261022`) across 6 strata (`E0_SHORT`, `E0_LONG`, `E1_SHORT`, `E1_LONG`, `E2PLUS_SHORT`, `E2PLUS_LONG`) with minimum quota 2 per stratum and largest-remainder proportional allocation.
  - Record inclusion probabilities $\pi_h = n_h / N_h$ for Horvitz-Thompson weighted sentence error rate estimation ($\hat{p}_{\text{error}}$).

### 3.2. Annotator Models & High Thinking Effort Client (`9router`)
- **Annotator Configuration**:
  ```python
  ANNOTATORS = {
      "A1": {"model": "cx/gpt-6-luna", "reasoning_effort": "high"},
      "A2": {"model": "ag/gemini-3.8-flash-high", "reasoning_effort": "high"},
  }
  ```
- **API Request Payload**:
  - Endpoint: `http://localhost:20128/v1/chat/completions` (configurable via `NINEROUTER_BASE_URL` and `NINEROUTER_API_KEY`).
  - Include `"reasoning_effort": reasoning_effort` (default `"high"`, configurable via `--reasoning-effort`).
  - Verified live against 9router:
    - `cx/gpt-6-luna` with `reasoning_effort="high"` $\rightarrow$ `HTTP 200`, valid JSON.
    - `ag/gemini-3.8-flash-high` with `reasoning_effort="high"` $\rightarrow$ `HTTP 200`, valid JSON with reasoning tokens active.
  - Strip `<think>...</think>` blocks if present before JSON parsing, and automatically retry stubborn samples individually (`batch_size=1`) if a multi-sentence batch fails validation.

### 3.3. Alignment of `AUDIT_PROMPT` with 18-Class NERGRIT Specification
- Update `AUDIT_PROMPT` in [scripts/run_independent_audit_iaa.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/run_independent_audit_iaa.py) so all 18 classes and transformation rules match [verify_nemotron_ultra.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/verify_nemotron_ultra.py), [verify_gemma_nemotron_vl.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/verify_gemma_nemotron_vl.py), and [verify_luna_gemini.py](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/verify_luna_gemini.py):
  1. **`PER`**: Absorbs attached military/police/academic titles (`Dr.`, `Prof.`, `Jenderal`, `Kombes`, `Aiptu`); drops generic honorifics (`Bapak`, `Ibu` $\rightarrow$ `O`).
  2. **`NOR` vs `ORG`**: `NOR` covers police/military (`Polri`, `TNI`), ministries/state agencies (`KPK`, `DPR`, `KPU`, `BMKG`, `pemerintah`), political parties (`PDIP`, `PKS`, `Golkar`), intergovernmental bodies (`PBB`, `WHO`), ethnic/national groups, and standalone/structural state leadership titles (`Presiden`, `Menteri`, `Gubernur`, `Bupati`, `Kapolri`, `Panglima TNI`). `ORG` covers private companies, BUMN corporations (`Pertamina`, `PLN`, `Bank Mandiri`), media outlets (`detikcom`, `Kompas`), and sports clubs/national teams.
  3. **`PRD`**: Includes lowercase physical vehicles (`mobil`, `sepeda motor`, `truk`, `bus`, `kapal`, `pesawat`, `kereta api`), commodities (`BBM`, `beras`, `kopi`, `sabu`), gear (`helm`), devices, and platforms.
  4. **`QTY` / `DAT` / `TIM` / `ORD` / `CRD`**:
     - Time durations (`dua tahun`, `tiga bulan`, `24 jam`, `30 menit`) $\rightarrow$ `QTY`.
     - Parenthesized news datelines `Selasa ( 15 / 5 / 2018 )` $\rightarrow$ single unified `DAT` span including parentheses.
     - `TIM` excludes `pukul`, `jam`, `sekira`, and `pagi`/`siang`/`malam` (`O`).
     - Prepositions (`di`, `ke`, `dari`, `pada`, `dalam`, `selama`, `sejak`, `hingga`, `sampai`) excluded from all spans (except `ke` in `ORD` `ke - 4`).
  5. **`REG` & `TTL` Elimination**: Mapped to `O` (except regional areas like `Asia Tenggara` $\rightarrow$ `LOC`, public holidays `Lebaran`/`Natal` $\rightarrow$ `EVT`, physical mosques $\rightarrow$ `FAC`).

### 3.4. Output Directory & CLI Ergonomics
- Default output directory: `audit_iaa/` at repository root (matching the existing project structure in `1DEV/SKRIPSI` and `SKRIPSI/skripsi`), with automatic backup of any pre-existing `audit_iaa/` files to `audit_iaa/legacy_backup/` if `--fresh` is passed or when generating a new manifest.
- CLI flags:
  - `python scripts/run_independent_audit_iaa.py` — Run full pipeline (sample $\rightarrow$ annotate A1 & A2 in parallel $\rightarrow$ compute IAA & consensus $\rightarrow$ bundle `audit_iaa_results.zip`).
  - `--datasets nemotron,luna,gemma` — Select which datasets to include in the stratified audit.
  - `--annotator {A1,A2,both}` — Run a single annotator or both concurrently.
  - `--batch-size 5` / `--workers 4` — Control batch size and parallel worker threads.
  - `--max-batches 1` — Smoke test mode (run 1 batch per annotator and stop).
  - `--status` — Show live completion progress per annotator and per dataset.
  - `--compute-only` / `--allow-partial` — Recompute IAA metrics and `IAA_REPORT.md` from saved sample JSONs.

---

## 4. Open Question for User Confirmation

Before we write the code, please confirm your preferred default dataset scope for the IAA run:

1. **Option A (Recommended — 3 Verified 18-Class Synthetic Datasets = 300 samples)**:
   Audit the 3 newly verified 18-class synthetic datasets (`nemotron`, `luna`, `gemma` $\rightarrow$ $3 \times 100 = 300$ sentences, $600$ independent model evaluations).
2. **Option B (3 Verified Synthetic Datasets + Gold = 400 samples)**:
   Audit `gold`, `nemotron`, `luna`, and `gemma` ($4 \times 100 = 400$ sentences, $800$ independent model evaluations).
3. **Option C (All 6 Datasets including legacy `gpt_oss` & `benchmark` = 600 samples)**:
   Audit `gold`, `nemotron`, `luna`, `gemma`, plus legacy `gpt_oss` and `benchmark` ($6 \times 100 = 600$ sentences, $1,200$ evaluations).

---

## 5. Verification Plan

1. **Automated Unit Tests (`tests/test_independent_audit_iaa.py`)**:
   - Verify `align_entities_to_bio`, `entity_spans`, and stratified quota calculation (`_quotas`).
   - Verify `normalize_result` response validation (`KEEP`, `REMOVE`, `REPLACE`, `missing_entities`, overlap detection, `REG`/`TTL` auto-drop).
   - Verify `kappa`, `unit_stats`, `consensus_spans` (dual-agreement rule), and `bootstrap` CI calculation.
2. **Live 9router Smoke Test**:
   - Run `python scripts/run_independent_audit_iaa.py --max-batches 1 --batch-size 2 --allow-partial` against `cx/gpt-6-luna` (high) and `ag/gemini-3.8-flash-high` (high) to verify end-to-end checkpointing and partial IAA computation.
3. **Dual-Repository Synchronization**:
   - Synchronize `scripts/run_independent_audit_iaa.py` and `tests/test_independent_audit_iaa.py` across both `C:\Users\tream\OneDrive\Documents\1DEV\SKRIPSI` and `C:\Users\tream\OneDrive\Documents\SKRIPSI\skripsi`.
