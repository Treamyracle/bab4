# Walkthrough: Colab Experiment Notebook — NERGRIT Gold vs. Nemotron 18-Class Verified

## 1. Overview & Compliance with User Requirements

All requirements from the approved implementation plan and user comments have been implemented and verified:

1. **Per-Cell `.py` Architecture (`cell1.py` $\rightarrow$ `cell10.py` $\rightarrow$ `.ipynb`)**:
   - Every cell in [`Eksperimen_Nemotron_18Class_Colab.ipynb`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_Colab.ipynb) is compiled directly from an individual Python file in [`notebooks/Eksperimen_Nemotron_18Class_cells/`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/) via [`build_nemotron_18class_notebook.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/scripts/build_nemotron_18class_notebook.py).
2. **Single Random Seed (`TRAINING_SEEDS = [42]`)**:
   - Configured in [`cell2.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell2.py#L46-L49) with `RUN_ALL_3_SEEDS = False` and `TRAINING_SEEDS = [42]` by default (1 fine-tuning run for `gold` + 1 fine-tuning run for `nemotron_18class`).
3. **Exact Skripsi Hyperparameters (Tabel 3.2)**:
   - Model: `indobenchmark/indobert-large-p1`
   - Sequence Length: `256` (with lossless word-aligned BIO chunking and label-blind inference chunking)
   - Effective Batch Size: `16` (`per_device_train_batch_size = 16`, `gradient_accumulation_steps = 1`)
   - Optimizer & Schedule: `AdamW` (`lr = 2e-5`, `weight_decay = 0.01`, `warmup_ratio = 0.1`, linear decay)
   - Epochs & Early Stopping: `max_epochs = 5`, `EarlyStoppingCallback(early_stopping_patience=2)` on validation `eval_f1`
4. **Automatic Data Bundle & Google Drive Sync**:
   - Created [`nemotron_18class_colab_bundle.zip`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/nemotron_18class_colab_bundle.zip) (`~2.55 MB`, SHA-256: `cc29515ffcab4f109d4c962c6f4791676aa66d1bdd5b0ebc6c6b78447170a612`) containing NERGRIT Gold (`train.txt`, `valid.txt`, `test.txt`, `labels-map.csv`) and the newly completed 17,525-sentence Nemotron 18-Class corpus (`corrected.jsonl` + `state.json`).
   - Automatically mounts Google Drive to `/content/drive/MyDrive/SKRIPSI_NER_BAB4/eksperimen_nemotron_18class/` and automatically syncs:
     - The input data bundle (`nemotron_18class_colab_bundle.zip`)
     - Mid-training epoch checkpoints (`checkpoint-*`) and verified `best_model` directories (`IntegrityAndDriveSyncCallback`)
     - The final analysis archive (`nemotron_18class_experiment_results.zip`)
5. **Zero Skripsi Content Changes**:
   - No files in `laporan/` (`BAB_1.md` through `BAB_5.md`, `LAMPIRAN_*.md`) were modified.

---

## 2. Per-Cell Architecture (`cell1.py` .. `cell10.py`)

| Cell | Source File | Role |
| :--- | :--- | :--- |
| **Cell 1** | [`cell1.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell1.py) | Markdown header: experiment design, 18-class taxonomy (`REG` & `TTL` $\rightarrow$ `O`), and Tabel 3.2 hyperparameter specification. |
| **Cell 2** | [`cell2.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell2.py) | Experiment constants (`TRAINING_SEEDS = [42]`, hyperparameters, 37 BIO tags), automatic Google Drive mount, and `sync_to_drive()` helper. |
| **Cell 3** | [`cell3.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell3.py) | Package installation (`transformers`, `datasets`, `accelerate`, `seqeval`), GPU detection (`BF16` on A100/L4, `FP16` fallback on T4), and deterministic seeding. |
| **Cell 4** | [`cell4.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell4.py) | Automatic download/extraction of `nemotron_18class_colab_bundle.zip` (Drive cache $\rightarrow$ GitHub clone $\rightarrow$ local upload fallback), SHA-256 verification, and automatic Drive backup. |
| **Cell 5** | [`cell5.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell5.py) | CoNLL & JSONL loaders, `REG`/`TTL` $\rightarrow$ `O` sanitization, 5-gram Jaccard $\ge 0.90$ deduplication & leakage prevention (`train_hash[:12] == "26d1055a4d59"` matching Bab 4 Gold 100%), and `dataset_audit_summary.json`. |
| **Cell 6** | [`cell6.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell6.py) | Subword tokenization (`max_seq_length = 256`), label-blind inference chunking (`recombine_predictions`), `seqeval` strict span evaluation, and `train_scenario_model` with automatic Drive checkpointing & resume. |
| **Cell 7** | [`cell7.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell7.py) | Scenario 1 Runner: Fine-tunes `indobenchmark/indobert-large-p1` on **NERGRIT Gold** (`seed = 42`) and backs up `best_model` + telemetry to Google Drive. |
| **Cell 8** | [`cell8.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell8.py) | Scenario 2 Runner: Fine-tunes `indobenchmark/indobert-large-p1` on **Nemotron 18-Class Verified** (`seed = 42`) and backs up `best_model` + telemetry to Google Drive. |
| **Cell 9** | [`cell9.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell9.py) | Head-to-Head Evaluation on the **NERGRIT Gold Test Set** (`2,423` clean sentences): computes overall Micro/Macro/Weighted Precision, Recall, F1, deltas ($\Delta$), and per-entity 18-class breakdown. |
| **Cell 10** | [`cell10.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/notebooks/Eksperimen_Nemotron_18Class_cells/cell10.py) | Span error taxonomy analysis (Boundary Error, Type Confusion, Spurious FP, Missed FN), comparison charts, packaging into `nemotron_18class_experiment_results.zip`, automatic upload to Google Drive, and browser download. |

---

## 3. Contents of Output Archive (`nemotron_18class_experiment_results.zip`)

When the notebook finishes running Cell 10, it creates `nemotron_18class_experiment_results.zip` (and automatically uploads it to `/content/drive/MyDrive/SKRIPSI_NER_BAB4/eksperimen_nemotron_18class/nemotron_18class_experiment_results.zip`), containing:

- `experiment_metadata.json` — Hardware telemetry, library versions, hyperparameters, and bundle hashes
- `dataset_audit_summary.json` — Sentence/entity counts per class and split for Gold vs. Nemotron 18-Class
- `head_to_head_summary.json` & `head_to_head_summary.csv` — Overall Micro, Macro, and Weighted P/R/F1 comparison and $\Delta$
- `per_class_comparison_18entities.csv` — 18-class F1, Precision, Recall, Support, and $\Delta\text{F1}$ (`Nemotron_18Class - Gold`)
- `error_taxonomy_comparison.json` — Detailed counts and sample sentences of Boundary Error, Type Confusion, Spurious FP, and Missed FN
- `predictions/gold_s42_test_predictions.jsonl` & `predictions/nemotron_18class_s42_test_predictions.jsonl` — Full token-level predictions on the 2,423 Gold test sentences
- `runs/*/run_manifest.json`, `training_log_history.json`, `val_metrics.json`, `test_metrics.json` — Epoch-by-epoch training loss and validation curves
- `plots/per_class_f1_comparison.png` & `plots/error_taxonomy_breakdown.png` — High-resolution comparison charts

---

## 4. Verification & Dual-Repository Synchronization

- **Unit & Integration Test Suite**: [`tests/test_nemotron_18class_notebook.py`](file:///c:/Users/tream/OneDrive/Documents/1DEV/SKRIPSI/tests/test_nemotron_18class_notebook.py) verifies bundle SHA-256 integrity, compilation of all 10 cells, `nbformat` validation, exact Bab 4 Gold partition hash parity (`26d1055a4d59`), lossless chunking, mocked `Trainer` execution with Google Drive checkpoint sync/resume, and final `.zip` generation.
- **Synchronized Commits**:
  - `1DEV/SKRIPSI` (`Treamyracle/bab4`): commit `34eae30` (`main`)
  - `SKRIPSI/skripsi` (`Treamyracle/skripsi`): commit `de04072` (`main`)

---

## 5. Korpus Luna & Gemma 18-Class Verification Scripts

As defined in the approved plan, two dedicated production verifier scripts were implemented and verified across both repositories:

### A. Korpus Luna Verifier (`scripts/verify_luna_gemini.py`)
- **Target Dataset**: `raw_distilled_luna_17427.json` (17,427 sentences from Hugging Face Hub)
- **Model**: `ag/gemini-3.8-flash-low`
- **Gateway**: Local 9router (`http://localhost:20128/v1/chat/completions`)
- **Key Features**:
  - Handles JSON response parsing and SSE line-by-line fallback parsing.
  - Automatically absorbs military/police ranks (`Letjen`, `Mayjen`, `Irjen`, `Kombes`, `Kolonel`, dll.) into the `PER` entity (e.g. `"Letjen Suharyanto"` $\rightarrow$ `PER`).
  - Standardizes institutional leadership titles into `NOR` (e.g. `"Kepala BNPB"` $\rightarrow$ `NOR`).
  - Re-joins fragmented date components into unified compound `DAT` entities (e.g. `"Senin"` + `", 21 Mei 2018"` $\rightarrow$ `"Senin, 21 Mei 2018"`).
  - Checkpointing every 50 batches with clean resumption support (`--resume`).

### B. Korpus Gemma Verifier (`scripts/verify_gemma_nemotron_vl.py`)
- **Target Dataset**: `raw_distilled_gemma_17434.json` (17,434 sentences from Hugging Face Hub)
- **Model**: `nvidia/nemotron-3.5-super-vl:free`
- **Gateway**: OpenRouter API (`https://openrouter.ai/api/v1/chat/completions`)
- **Key Features**:
  - Automatically formats API keys (ensuring `sk-or-v1-` prefix).
  - Handles reasoning token stream extraction (`reasoning` vs `content` fields).
  - Filters out legacy `REG` & `TTL` tags into `O`.
  - Checkpointing every 50 batches with clean resumption support (`--resume`).

---

## 6. Verification Results & Test Suite

### Smoke Test Results:
1. **Luna Verifier Smoke Test (`ag/gemini-3.8-flash-low` via 9router)**:
   - Downloaded `raw_distilled_luna_17427.json` (5.80 MB) from Hugging Face Hub.
   - Tested live on 2 complex benchmark sentences:
     - Sentence 1: `[PER] Letjen Suharyanto`, `[NOR] Kepala BNPB`, `[DAT] Kamis 15 Februari 2024`, `[GPE] Jakarta`, `[MON] Rp 500 miliar`.
     - Sentence 2: `[ORG] PT Pertamina`, `[PRD] BBM Solar`, `[QTY] 100 ribu kiloliter`, `[LOC] Selat Malaka`, `[EVT] KTT ASEAN`.
   - **Result**: `🎉 ALL SMOKE TEST ASSERTIONS PASSED PERFECTLY!` (HTTP 200 in 2.21s).

2. **Gemma Verifier Smoke Test (`nvidia/nemotron-3.5-super-vl:free` via OpenRouter)**:
   - Downloaded `raw_distilled_gemma_17434.json` (5.69 MB) from Hugging Face Hub.
   - Tested live on 2 complex benchmark sentences:
     - Sentence 1: `[NOR] Menteri Ketenagakerjaan`, `[PER] Ida Fauziah`, `[ORG] Bulog`, `[QTY] 5 juta ton`, `[PRD] beras`, `[GPE] Jawa Barat`, `[DAT] Januari 2024`.
     - Sentence 2: `[PER] Bambang Surya`, `[EVT] Festival Budaya Nusantara`, `[FAC] Museum Nasional`, `[GPE] Jakarta`, `[NOR] UNESCO`.
   - **Result**: `🎉 ALL SMOKE TEST ASSERTIONS PASSED PERFECTLY!` (HTTP 200 in 22.55s, 6,727 tokens).

3. **Unit Test Suite (`tests/test_verify_luna_and_gemma.py`)**:
   - 6 unit test cases covering SSE stream parsing, reasoning extraction, API key formatting, rank absorption, 18-class boundary rules, and token BIO tag alignment.
   - **Result**: `Ran 6 tests in 0.001s: OK` in both `1DEV/SKRIPSI` and `SKRIPSI/skripsi`.

---

## 7. Execution Commands for Verification Runs

Both scripts can be run sequentially or in parallel terminal tabs:

### Option A: Run Korpus Luna Verification (9router)
```bash
python scripts/verify_luna_gemini.py --batch-size 4 --delay 0.2
```
*(If interrupted, rerun with `--resume` to continue seamlessly from the last checkpoint)*

### Option B: Run Korpus Gemma Verification (OpenRouter)
```bash
python scripts/verify_gemma_nemotron_vl.py --batch-size 4 --delay 1.0
```
*(If interrupted, rerun with `--resume` to continue seamlessly from the last checkpoint)*

