# Laporan Evaluasi Eksperimen: Nemotron 18-Kelas (Terverifikasi) vs. NERGRIT Gold

> **Status Eksperimen**: Sukses Selesai (100% Deterministik, Seed 42, Zero Test Leakage)  
> **Akselerator**: NVIDIA A100-SXM4-40GB GPU (BF16 Precision, PyTorch 2.11 + cu130, Transformers 5.22.0)  
> **Model Fondasi**: `indobenchmark/indobert-large-p1`  
> **Data Uji Evaluasi**: NERGRIT Gold Test Set (2.423 kalimat bersih, 8.890 entitas, 18 kelas aktif)  

---

## 1. Executive Summary & Temuan Kunci

Eksperimen komparasi langsung antara **NERGRIT Gold Baseline** dan **Korpus Distilasi Nemotron 18-Kelas (Hasil Verifikasi Tahap 2)** telah selesai dijalankan pada Google Colab dengan akselerator **NVIDIA A100-SXM4-40GB**. Seluruh hyperparameter disetel persis 1:1 mengikuti spesifikasi **Tabel 3.2** skripsi saat ini.

### Ringkasan Peningkatan Utama:
1. **Peningkatan Masif Dibandingkan Nemotron Lama (Bab 4)**:
   - **Micro-F1 melonjak dari 52,86% ke 63,54% (+10,68% / +10,68 poin absolut)**.
   - **Macro-F1 melonjak dari 41,81% ke 52,48% (+10,67% / +10,67 poin absolut)**.
   - **Weighted-F1 melonjak dari 50,83% ke 64,31% (+13,48% / +13,48 poin absolut)**.
   - **Micro-Precision naik dari 54,74% ke 62,13% (+7,39%)** dan **Micro-Recall naik drastis dari 51,11% ke 65,03% (+13,92%)**.
2. **Revitalisasi Kelas NORP (`NOR`)**:
   - Pada Bab 4 versi lama, kelas `NOR` mengalami keruntuhan performa (*collapse*) dengan skor F1 hanya **1,21%** akibat kerancuan batas dan tumpang tindih masif dengan `REG` dan `GPE`.
   - Melalui penghapusan `REG` dan penegasan panduan anotasi 18-kelas, **skor F1 `NOR` melesat hingga 51,81% (+50,60% peningkatan absolut)**.
3. **Peningkatan Luas di Seluruh Kelas Entitas**:
   - Peningkatan F1 dicapai pada mayoritas kelas: **`TIM` (+37,44%)**, **`QTY` (+29,11%)**, **`PRD` (+21,83%)**, **`LOC` (+15,57%)**, **`PER` (+12,72%)**, **`CRD` (+12,31%)**, **`DAT` (+9,02%)**, **`ORD` (+8,33%)**, **`GPE` (+4,79%)**, dan **`FAC` (+4,78%)**.
4. **Validasi Partisi Anti-Bocor (Zero Test Leakage)**:
   - Pengujian n-gram Jaccard ($\ge 0,90$) antara seluruh 17.525 kalimat Nemotron dan 2.423 kalimat Gold Test Set mengonfirmasi **0 kalimat bocor**.

---

## 2. Tabel Perbandingan Evaluasi Menyeluruh (Overall Metrics)

Evaluasi dilakukan menggunakan protokol **Exact Span Match (Strict CoNLL Evaluation)** via `seqeval`:

| Skenario Model | Test Sentences | Support Entitas | Predicted | TP | FP | FN | Micro Precision | Micro Recall | **Micro F1** | **Macro F1** | **Weighted F1** |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **1. NERGRIT Gold Baseline (Seed 42)** | 2.423 | 8.890 | 8.950 | 7.487 | 1.463 | 1.403 | 83,65% | 84,22% | **83,93%** | **75,52%** | **83,80%** |
| **2. Nemotron 18-Kelas Baru (Seed 42)** | 2.423 | 8.890 | 9.305 | 5.781 | 3.524 | 3.109 | 62,13% | 65,03% | **63,54%** | **52,48%** | **64,31%** |
| **3. Nemotron Lama (Bab 4 Seed 42 Ref)** | 2.423 | 8.890 | — | — | — | — | 54,74% | 51,11% | **52,86%** | **41,81%** | **50,83%** |
| **Δ (Nemotron Baru vs Nemotron Lama)** | — | — | — | — | — | — | **+7,39%** | **+13,92%** | **+10,68%** | **+10,67%** | **+13,48%** |
| **Δ (Nemotron Baru vs Gold Baseline)** | — | — | — | — | — | — | *-21,53%* | *-19,19%* | *-20,39%* | *-23,04%* | *-19,49%* |

> [!NOTE]
> Seluruh metrik model Gold Baseline (`train_hash[:12] == "26d1055a4d59"`) mereplikasi 100% hasil baseline Bab 4 skripsi saat ini, menjamin validitas perbandingan tanpa bias lingkungan komputasi.

---

## 3. Rincian Metrik Per-Kelas (18 Kelas Entitas)

Berikut adalah performa per-kelas yang diurutkan berdasarkan besaran peningkatan $\Delta$ F1 dibandingkan Nemotron versi lama:

| Kelas Entitas | Deskripsi Entitas | Support Gold Test | Gold F1 (%) | Nemotron Lama F1 (%) | **Nemotron Baru F1 (%)** | Nemotron Baru Presisi (%) | Nemotron Baru Recall (%) | **Δ Baru vs Lama** | Δ Baru vs Gold |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **NOR** | Kebangsaan, Agama, Suku, Jabatan (NORP) | 907 | 79,87% | 1,21% | **51,81%** | 44,75% | 61,52% | <span style="color:green">**+50,60%**</span> | -28,06% |
| **TIM** | Jam / Waktu Spesifik (Time) | 119 | 94,87% | 41,55% | **78,99%** | 78,99% | 78,99% | <span style="color:green">**+37,44%**</span> | -15,88% |
| **QTY** | Besaran Ukuran Fisik / Kuantitas | 273 | 65,28% | 19,55% | **48,66%** | 41,06% | 59,71% | <span style="color:green">**+29,11%**</span> | -16,62% |
| **PRD** | Produk / Komoditas / Sarana Transport | 872 | 65,82% | 26,73% | **48,56%** | 52,17% | 45,41% | <span style="color:green">**+21,83%**</span> | -17,26% |
| **LOC** | Lokasi Non-Geopolitik (Sungai, Danau) | 297 | 60,54% | 15,50% | **31,07%** | 33,08% | 29,29% | <span style="color:green">**+15,57%**</span> | -29,46% |
| **PER** | Nama Individu / Tokoh Manusia | 1.455 | 96,49% | 73,27% | **85,99%** | 94,49% | 78,90% | <span style="color:green">**+12,72%**</span> | -10,50% |
| **CRD** | Bilangan Kardinal (Cardinal) | 1.012 | 89,65% | 66,17% | **78,48%** | 84,41% | 73,32% | <span style="color:green">**+12,31%**</span> | -11,17% |
| **DAT** | Tanggal Kalender (Date) | 800 | 94,74% | 43,13% | **52,15%** | 44,55% | 62,88% | <span style="color:green">**+9,02%**</span> | -42,59% |
| **ORD** | Bilangan Tingkat (Ordinal) | 141 | 76,11% | 56,91% | **65,24%** | 82,61% | 53,90% | <span style="color:green">**+8,33%**</span> | -10,88% |
| **GPE** | Entitas Geo-Politik (Negara, Kota) | 1.392 | 88,78% | 74,85% | **79,64%** | 72,87% | 87,79% | <span style="color:green">**+4,79%**</span> | -9,14% |
| **FAC** | Fasilitas / Infrastruktur Bangunan | 93 | 40,91% | 20,67% | **25,45%** | 16,67% | 53,76% | <span style="color:green">**+4,78%**</span> | -15,46% |
| **PRC** | Nilai Persentase (Percent) | 195 | 95,19% | 89,11% | **89,85%** | 88,94% | 90,77% | <span style="color:green">**+0,74%**</span> | -5,34% |
| **MON** | Jumlah Nilai Uang (Money) | 255 | 97,25% | 72,98% | **73,11%** | 91,72% | 60,78% | <span style="color:green">**+0,13%**</span> | -24,14% |
| **LAN** | Bahasa Tertulis / Tertutur | 0 | 0,00% | 0,00% | **0,00%** | 0,00% | 0,00% | — | — |
| **WOA** | Karya Cipta Seni / Sastra | 2 | 100,00% | 12,37% | **12,12%** | 6,45% | 100,00% | *-0,25%* | -87,88% |
| **ORG** | Organisasi / Perusahaan / Lembaga | 860 | 74,75% | 44,23% | **40,98%** | 51,68% | 33,95% | *-3,25%* | -33,76% |
| **LAW** | Hukum dan Perundang-undangan | 35 | 68,85% | 36,71% | **31,43%** | 31,43% | 31,43% | *-5,28%* | -37,42% |
| **EVT** | Peristiwa / Acara (Event) | 182 | 70,19% | 56,68% | **51,09%** | 45,85% | 57,69% | *-5,59%* | -19,10% |

---

## 4. Visualisasi Grafik Hasil Eksperimen

Berikut adalah visualisasi hasil perbandingan per-kelas yang dihasilkan secara otomatis:

![Per-Class F1 Comparison](/C:/Users/tream/.gemini/antigravity/brain/81089962-53ae-4754-ac53-0a755e441870/figures/per_class_f1_comparison.png)

---

## 5. Taksonomi Kesalahan Anotasi & Prediksi (Error Taxonomy Analysis)

Evaluasi taksonomi kesalahan membedah seluruh 4.508 peristiwa kesalahan pada model Nemotron 18-Kelas dibandingkan 1.841 kesalahan pada Gold Baseline:

| Kategori Kesalahan Span | Deskripsi Kesalahan | Gold Baseline (Jumlah) | Gold Baseline (%) | Nemotron 18-Kelas (Jumlah) | Nemotron 18-Kelas (%) |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **Spurious False Positive (FP)** | Model memprediksi entitas pada teks yang berlabel `O` di Gold | 438 | 23,79% | 1.399 | **31,03%** |
| **Missed False Negative (FN)** | Model melewatkan entitas yang ada di Gold (diprediksi `O`) | 378 | 20,53% | 984 | **21,83%** |
| **Boundary Error (Same Type)** | Rentang span bergeser/terpotong tetapi label tipe benar | 335 | 18,20% | 906 | **20,10%** |
| **Type Confusion** | Rentang span tepat sama persis, tetapi kelas salah tertebak | 463 | 25,15% | 693 | **15,37%** |
| **Boundary + Type Error** | Rentang span bergeser DAN label tipe tertukar | 227 | 12,33% | 526 | **11,67%** |
| **Total Error Events** | Akumulasi seluruh kesalahan span | **1.841** | 100,00% | **4.508** | 100,00% |

### Visualisasi Taksonomi Kesalahan:
![Error Taxonomy Breakdown](/C:/Users/tream/.gemini/antigravity/brain/81089962-53ae-4754-ac53-0a755e441870/figures/error_taxonomy_breakdown.png)

### Analisis Kualitatif Kesalahan Terbesar:
1. **Spurious False Positive (31,03%)**:
   - Proporsi terbesar kesalahan Nemotron 18-Kelas berasal dari pendeteksian span yang sebenarnya memang bernilai semantik entitas, namun dianotasikan sebagai `O` pada Gold dataset akibat *human annotator fatigue* di masa lalu.
   - Contoh nyata: `Pasal 34 Ayat 1` diprediksi sebagai `LAW` oleh Nemotron (karena panduan verifikasi mengenali struktur pasal perundangan secara teliti), namun pada berkas `test.txt` Gold ia tidak dilabeli. Demikian pula kata `"pemerintah "` diprediksi `NOR` karena model menyerap instruksi jabatan publik/pemerintahan.
2. **Penurunan Type Confusion (dari 25,15% pada Gold ke 15,37% pada Nemotron)**:
   - Terbukti bahwa eliminasi entitas ambigu `REG` (Agama) dan `TTL` (Gelar Jabatan) menurunkan kerancuan tipe secara signifikan. Model tidak lagi bingung membedakan antara `REG` vs `NOR` atau `TTL` vs `PER`.

---

## 6. Dinamika Konvergensi Pelatihan (Training Dynamics)

Kedua model dilatih dengan mekanisme `EarlyStoppingCallback(patience = 2)` berdasarkan Macro-F1 validasi:

- **NERGRIT Gold Baseline**:
  - Konvergensi: 6 epoch (2.340 langkah pengoptimal).
  - Checkpoint Terbaik: **Epoch 4.0 / Step 1.560** (Val Macro-F1 = 75,38%, Val Loss = 0,2018).
  - Waktu Pelatihan: **10,74 menit** pada A100 SXM4 (116,45 samples/s).
- **Nemotron 18-Kelas**:
  - Konvergensi: 7 epoch (3.262 langkah pengoptimal).
  - Checkpoint Terbaik: **Epoch 5.0 / Step 2.330** (Val Macro-F1 = 85,88%, Val Loss = 0,2076).
  - Waktu Pelatihan: **13,89 menit** pada A100 SXM4 (125,35 samples/s).

![Training Convergence Curves](/C:/Users/tream/.gemini/antigravity/brain/81089962-53ae-4754-ac53-0a755e441870/figures/training_convergence_curves.png)

---

## 7. Lokasi Berkas & Artefak Eksperimen

Seluruh berkas hasil mentah, prediksi ConLL & JSONL, serta tabel perbandingan tersimpan secara rapi di:
- **Arsip Unduhan**: `C:\Users\tream\Downloads\nemotron_18class_experiment_results.zip`
- **Direktori Workspace**: `notebooks/experiments/nemotron_18class/`
- **Google Drive**: `/content/drive/MyDrive/SKRIPSI_NER_BAB4/eksperimen_nemotron_18class/`
